#include <stdio.h>
main()
{
	FILE *f;
	f=popen("sndserver -quiet", "w");
}
