#include "sndserver.h"
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/audioio.h>
#include <sys/types.h>
#include <stropts.h>
#include <sys/conf.h>
#include <sys/bufmod.h>
#include "irix.h"

int	audio_fd;

void myioctl(int fd, int command, void *arg)
{   
    int rc;
	extern int errno;
    rc = ioctl(fd, command, arg);  
	if (rc < 0)
	{
		fprintf(stderr, "ioctl(dsp,%d,arg) failed\n", command);
		fprintf(stderr, "errno=%d\n", errno);
	}
}

void I_InitMusic(void)
{
}

void I_InitSound(int samplerate, int samplesize)
{

    int i;
    char *audio_filename = "/dev/audio";
	audio_info_t audio_info;
                
    if (getenv("AUDIODEV"))
		audio_filename = getenv("AUDIODEV");

    audio_fd = open(audio_filename, O_RDWR);
    if (audio_fd<0)
        fprintf(stderr, "Could not open %s\n", audio_filename);

    myioctl(audio_fd, AUDIO_GETINFO, &audio_info);

	AUDIO_INITINFO(&audio_info);
	audio_info.play.sample_rate = 11025;
	myioctl(audio_fd, AUDIO_SETINFO, &audio_info);
	AUDIO_INITINFO(&audio_info);
	audio_info.play.channels = 2;
	myioctl(audio_fd, AUDIO_SETINFO, &audio_info);
	AUDIO_INITINFO(&audio_info);
	audio_info.play.precision = 16;
	myioctl(audio_fd, AUDIO_SETINFO, &audio_info);
	AUDIO_INITINFO(&audio_info);
	audio_info.play.encoding = AUDIO_ENCODING_LINEAR;
	myioctl(audio_fd, AUDIO_SETINFO, &audio_info);
	AUDIO_INITINFO(&audio_info);
	audio_info.play.buffer_size = 1024;
	myioctl(audio_fd, AUDIO_SETINFO, &audio_info);

}

void I_SubmitOutputBuffer(void *samples, int samplecount)
{
/*	myioctl(audio_fd, AUDIO_DRAIN, 0); */
	write(audio_fd, samples, samplecount*4);
}

void I_ShutdownSound(void)
{

	close(audio_fd);

}

void I_ShutdownMusic(void)
{
}
