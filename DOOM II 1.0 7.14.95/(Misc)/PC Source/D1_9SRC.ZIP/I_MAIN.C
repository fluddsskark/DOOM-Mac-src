
#include "doomdef.h" 
 
 
void main (int argc, char **argv) 
{ 
	myargc = argc; 
	myargv = argv; 
 
	D_DoomMain (); 
} 
